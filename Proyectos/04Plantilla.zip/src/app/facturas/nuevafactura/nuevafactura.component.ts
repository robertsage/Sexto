import { Component } from '@angular/core';

@Component({
  selector: 'app-nuevafactura',
  standalone: true,
  imports: [],
  templateUrl: './nuevafactura.component.html',
  styleUrl: './nuevafactura.component.scss'
})
export class NuevafacturaComponent {

}
