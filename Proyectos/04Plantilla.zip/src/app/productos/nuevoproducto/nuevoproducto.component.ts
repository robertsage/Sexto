import { Component } from '@angular/core';

@Component({
  selector: 'app-nuevoproducto',
  standalone: true,
  imports: [],
  templateUrl: './nuevoproducto.component.html',
  styleUrl: './nuevoproducto.component.scss'
})
export class NuevoproductoComponent {

}
