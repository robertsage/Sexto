export interface Iproveedor {
    idProveedores: number;
    Nombre_Empresa: string;
    Direccion: string;
    Telefono: string;
    Contacto_Empresa: string;
    Teleofno_Contacto: string;
}
