import { Component } from '@angular/core';

@Component({
  selector: 'app-nuevocliente',
  standalone: true,
  imports: [],
  templateUrl: './nuevocliente.component.html',
  styleUrl: './nuevocliente.component.scss'
})
export class NuevoclienteComponent {

}
