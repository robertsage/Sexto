export interface Iproducto {
    idProductos: number;
    Codigo_Barras: string;
    Nombre_Producto: string;
    Graba_IVA: number;
}
