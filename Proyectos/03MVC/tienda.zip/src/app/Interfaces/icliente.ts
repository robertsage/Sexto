export interface ICliente {
    idClientes: number;
    Nombres: string;
    Direccion: string;
    Telefono: string;
    Cedula: string;
    Correo: string;
}
